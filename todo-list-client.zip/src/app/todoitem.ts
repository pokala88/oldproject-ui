export class TodoItem {
    id: number;
    itemName: string;
    description: string;
    status: boolean;
}
