import { Component, OnInit } from '@angular/core';
import { TodoitemService } from '../todoitem.service';
import { TodoItem } from '../todoitem';
import { Router } from '@angular/router';


@Component({
  selector: 'app-create-todoitem',
  templateUrl: './create-todoitem.component.html',
  styleUrls: ['./create-todoitem.component.css']
})

export class CreateTodoitemComponent implements OnInit {

  todoItem: TodoItem = new TodoItem();
  submitted = false;

  constructor(private todoItemService: TodoitemService,
    private router: Router) { }

  ngOnInit() {
  }

  newTodoItem(): void {
    this.submitted = false;
    this.todoItem = new TodoItem();
  }

  save() {
    this.todoItemService
    .createTodoItem(this.todoItem).subscribe(data => {
      console.log(data)
      this.todoItem = new TodoItem();
      this.gotoList();
    },
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

  gotoList() {
    this.router.navigate(['/todoitems']);
  }
}


