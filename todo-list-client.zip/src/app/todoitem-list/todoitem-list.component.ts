import { Observable } from "rxjs";
import { TodoitemService } from "../todoitem.service";
import { TodoItem } from "../todoitem";
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todoitem-list',
  templateUrl: './todoitem-list.component.html',
  styleUrls: ['./todoitem-list.component.css']
})
export class TodoitemListComponent implements OnInit {

  todoItems: Observable<TodoItem[]>;

  constructor(private todoitemService: TodoitemService,
    private router: Router) {}

 ngOnInit() {
  this.reloadData();
}

  reloadData() {
    this.todoItems = this.todoitemService.getTodoItemList();
  }

  deleteTodoItem(id: number) {
    this.todoitemService.deleteTodoItem(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  updateTodoItem(id: number)
  {
    this.router.navigate(['update', id]);
  }

  todoItemDetails(id: number){
    this.router.navigate(['details', id]);
  }
}
