import { Component, OnInit } from '@angular/core';
import { TodoItem } from '../todoitem';
import { ActivatedRoute, Router } from '@angular/router';
import { TodoitemService } from '../todoitem.service';

@Component({
  selector: 'app-update-todoitem',
  templateUrl: './update-todoitem.component.html',
  styleUrls: ['./update-todoitem.component.css']
})
export class UpdateTodoItemComponent implements OnInit {


  id: number;
  todoitem: TodoItem;
  submitted = false;

  constructor(private route: ActivatedRoute,private router: Router,
    private todoitemService: TodoitemService) { }

  ngOnInit() {
    this.todoitem = new TodoItem();
    this.id = this.route.snapshot.params['id'];

    this.todoitemService.getTodoItem(this.id)
      .subscribe(data => {
        console.log(data)
        this.todoitem = data;
      }, error => console.log(error));
  }

  updateTodoitem() {
    this.todoitemService.updateTodoItem(this.id, this.todoitem)
      .subscribe(data => {
        console.log(data);
        this.todoitem = new TodoItem();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateTodoitem();
  }

  gotoList() {

    this.router.navigate(['/todoitems']);

  }

}
