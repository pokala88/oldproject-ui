import { TodoItem } from '../todoitem';
import { Component, OnInit, Input } from '@angular/core';
import { TodoitemService } from '../todoitem.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-todoitem-details',
  templateUrl: './todoitem-details.component.html',
  styleUrls: ['./todoitem-details.component.css']
})
export class TodoitemDetailsComponent implements OnInit {

  id: number;
  todoitem: TodoItem;

  constructor(private route: ActivatedRoute,private router: Router,
    private todoitemService: TodoitemService) { }

  ngOnInit() {
    this.todoitem = new TodoItem();

    this.id = this.route.snapshot.params['id'];

    this.todoitemService.getTodoItem(this.id)
      .subscribe(data => {
        console.log(data)
        this.todoitem = data;
      }, error => console.log(error));
  }

  list(){
        this.router.navigate(['todoitems']);
  }
}
