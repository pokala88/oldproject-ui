import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CreateTodoitemComponent } from './create-todoitem/create-todoitem.component';
import { TodoitemDetailsComponent } from './todoitem-details/todoitem-details.component';
import { TodoitemListComponent } from './todoitem-list/todoitem-list.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateTodoItemComponent } from './update-todoitem/update-todoitem.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateTodoitemComponent,
    TodoitemDetailsComponent,
    TodoitemListComponent,
    UpdateTodoItemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }



