import { TodoitemDetailsComponent } from './todoitem-details/todoitem-details.component';
import { CreateTodoitemComponent } from './create-todoitem/create-todoitem.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TodoitemListComponent } from './todoitem-list/todoitem-list.component';
import { UpdateTodoItemComponent } from './update-todoitem/update-todoitem.component';


const routes: Routes = [
  { path: '', redirectTo: 'todoitem', pathMatch: 'full' },
  { path: 'todoitems', component: TodoitemListComponent },
  { path: 'add', component: CreateTodoitemComponent },
  { path: 'update/:id', component: UpdateTodoItemComponent },
  { path: 'details/:id', component: TodoitemDetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
